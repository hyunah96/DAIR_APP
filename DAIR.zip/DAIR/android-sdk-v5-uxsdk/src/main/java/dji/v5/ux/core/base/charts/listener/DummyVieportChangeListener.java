package dji.v5.ux.core.base.charts.listener;

import dji.v5.ux.core.base.charts.model.Viewport;

public class DummyVieportChangeListener implements ViewportChangeListener {
    public DummyVieportChangeListener() {
        //do nothing
    }

    public void onViewportChanged(Viewport viewport) {
        //do nothing
    }
}
