package dji.v5.ux.core.ui.setting.ui;
/*
 *   WWWWWW||WWWWWW
 *    W W W||W W W
 *         ||
 *       ( OO )__________
 *        /  |           \
 *       /o o|    DJI     \
 *       \___/||_||__||_|| **
 *            || ||  || ||
 *           _||_|| _||_||
 *          (__|__|(__|__|
 *
 * Copyright (c) 2017, DJI All Rights Reserved.
 */

/**
 * <p>Description:</p>
 *
 * @author create at 2018/5/18 22:14 by luca for DJIPilot
 * @version v1.0
 */

public interface OnBackPressedHandler {
    void setSelectedFragment(AppFragment selectedFragment);
}
