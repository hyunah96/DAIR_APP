package dji.v5.ux.core.base.charts.provider;

import dji.v5.ux.core.base.charts.model.PieChartData;

public interface PieChartDataProvider {
    PieChartData getPieChartData();

    void setPieChartData(PieChartData var1);
}