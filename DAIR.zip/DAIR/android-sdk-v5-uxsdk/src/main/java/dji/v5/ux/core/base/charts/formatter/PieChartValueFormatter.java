package dji.v5.ux.core.base.charts.formatter;

import dji.v5.ux.core.base.charts.model.SliceValue;

public interface PieChartValueFormatter {
    int formatChartValue(char[] var1, SliceValue var2);
}

