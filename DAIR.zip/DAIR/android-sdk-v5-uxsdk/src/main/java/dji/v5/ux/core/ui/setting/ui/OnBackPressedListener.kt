package com.dji.industry.pilot.common

interface OnBackPressedListener {
    fun onBackPressed(): Boolean = false
}