package dji.v5.ux.core.base.charts.listener;

import dji.v5.ux.core.base.charts.model.BubbleValue;

public class DummyBubbleChartOnValueSelectListener implements BubbleChartOnValueSelectListener {
    public DummyBubbleChartOnValueSelectListener() {
        //do nothing
    }

    public void onValueSelected(int bubbleIndex, BubbleValue value) {
        //do nothing
    }

    public void onValueDeselected() {
        //do nothing
    }
}
