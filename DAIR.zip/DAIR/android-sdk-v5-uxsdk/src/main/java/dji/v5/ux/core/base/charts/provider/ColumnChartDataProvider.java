package dji.v5.ux.core.base.charts.provider;

import dji.v5.ux.core.base.charts.model.ColumnChartData;

public interface ColumnChartDataProvider {
    ColumnChartData getColumnChartData();

    void setColumnChartData(ColumnChartData var1);
}
