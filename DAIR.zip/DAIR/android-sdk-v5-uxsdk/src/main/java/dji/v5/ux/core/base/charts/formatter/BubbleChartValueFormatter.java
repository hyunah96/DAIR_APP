package dji.v5.ux.core.base.charts.formatter;

import dji.v5.ux.core.base.charts.model.BubbleValue;

public interface BubbleChartValueFormatter {
    int formatChartValue(char[] var1, BubbleValue var2);
}
