package dji.v5.ux.mapkit.core.constants;

public class MapkitConstants {

    public static final String KEY_SUPPORT_PROVIDER_LIST = "support_provider_list";
    public static final String KEY_SUPPORT_MAP_TYPE = "map_type";

    private MapkitConstants(){}
}
