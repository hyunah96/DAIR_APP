package dji.v5.ux.core.base.charts.util;

public class AxisAutoValues {
    public float[] values = new float[0];
    public int valuesNumber;
    public int decimals;

    public AxisAutoValues() {
        //do nothing
    }
}
