package dji.v5.ux.core.base.charts.animation;

public class DummyChartAnimationListener implements ChartAnimationListener {
    public DummyChartAnimationListener() {
        //do nothing
    }

    public void onAnimationStarted() {
        //do nothing
    }

    public void onAnimationFinished() {
        //do nothing
    }
}
