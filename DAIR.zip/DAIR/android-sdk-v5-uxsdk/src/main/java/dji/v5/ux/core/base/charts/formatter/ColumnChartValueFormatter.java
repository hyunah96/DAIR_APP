package dji.v5.ux.core.base.charts.formatter;

import dji.v5.ux.core.base.charts.model.SubcolumnValue;

public interface ColumnChartValueFormatter {
    int formatChartValue(char[] var1, SubcolumnValue var2);
}
