package dji.v5.ux.core.base.charts.gesture;

public enum ContainerScrollType {
    HORIZONTAL,
    VERTICAL;

    private ContainerScrollType() {
    }
}
