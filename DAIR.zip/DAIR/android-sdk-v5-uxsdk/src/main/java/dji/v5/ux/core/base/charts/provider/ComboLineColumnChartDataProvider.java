package dji.v5.ux.core.base.charts.provider;

import dji.v5.ux.core.base.charts.model.ComboLineColumnChartData;

public interface ComboLineColumnChartDataProvider {
    ComboLineColumnChartData getComboLineColumnChartData();

    void setComboLineColumnChartData(ComboLineColumnChartData var1);
}
