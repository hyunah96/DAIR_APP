package dji.v5.ux.mapkit.core.callback;

import android.graphics.Bitmap;

/**
 * Created by joeyang on 7/17/17.
 */

public interface MapScreenShotListener {
    void onMapScreenShot(Bitmap bitmap);
}
