package dji.v5.ux.core.base.charts.provider;

import dji.v5.ux.core.base.charts.model.BubbleChartData;

public interface BubbleChartDataProvider {
    BubbleChartData getBubbleChartData();

    void setBubbleChartData(BubbleChartData var1);
}

