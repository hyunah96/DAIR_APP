package dji.v5.ux.core.base.charts.listener;

import dji.v5.ux.core.base.charts.model.Viewport;

public interface ViewportChangeListener {
    void onViewportChanged(Viewport var1);
}
