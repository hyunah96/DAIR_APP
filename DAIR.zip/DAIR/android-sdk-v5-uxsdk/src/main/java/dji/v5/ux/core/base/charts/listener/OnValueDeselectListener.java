package dji.v5.ux.core.base.charts.listener;

public interface OnValueDeselectListener {
    void onValueDeselected();
}
