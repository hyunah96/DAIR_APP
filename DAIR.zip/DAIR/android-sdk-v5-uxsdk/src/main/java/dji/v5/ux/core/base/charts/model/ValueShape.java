package dji.v5.ux.core.base.charts.model;

public enum ValueShape {
    CIRCLE,
    SQUARE,
    DIAMOND;

    private ValueShape() {
    }
}
