package dji.v5.ux.core.base.charts.gesture;

public enum ZoomType {
    HORIZONTAL,
    VERTICAL,
    HORIZONTAL_AND_VERTICAL;

    private ZoomType() {
    }
}
